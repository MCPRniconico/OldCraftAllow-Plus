package org.extrateam.java

import net.fabricmc.api.ModInitializer
import org.slf4j.LoggerFactory


object OldCraftAllowPlus : ModInitializer {

    const val MOD_ID = "oldcraftallowplus"

    private val LOGGER =
        LoggerFactory.getLogger(MOD_ID)


    override fun onInitialize() {

        LOGGER.info("OldCraftAllow Plus loaded!")

    }
}